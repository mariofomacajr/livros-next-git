import type { Modifier } from "../types";
export declare type HideModifier = Modifier<"hide", {}>;
declare const _default: HideModifier;
export default _default;
