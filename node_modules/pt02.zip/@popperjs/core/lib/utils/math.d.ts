export declare const max: (...values: number[]) => number;
export declare const min: (...values: number[]) => number;
export declare const round: (x: number) => number;
