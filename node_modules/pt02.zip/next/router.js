module.exports = require('./dist/client/router')
