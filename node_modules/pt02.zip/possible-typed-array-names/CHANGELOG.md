# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/)
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## v1.0.0 - 2024-02-19

### Commits

- Initial implementation, tests, readme, types [`c279f55`](https://github.com/ljharb/possible-typed-array-names/commit/c279f550021896afa50c1169b3111618a96cf898)
- Initial commit [`0f22bf2`](https://github.com/ljharb/possible-typed-array-names/commit/0f22bf24d16fc8ea29483ed7ed378afb3758a4df)
- npm init [`25d6cff`](https://github.com/ljharb/possible-typed-array-names/commit/25d6cffe4091921e4e210704dabed37ae3d7b261)
- Only apps should have lockfiles [`a1bd592`](https://github.com/ljharb/possible-typed-array-names/commit/a1bd592fa037430d401b1d6d26cfea2c2d6789db)
